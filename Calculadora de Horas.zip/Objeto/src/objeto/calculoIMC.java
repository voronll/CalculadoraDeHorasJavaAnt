/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objeto;
import java.util.Scanner;

public class calculoIMC {
    public static void main(String[] args) {
        int m;
        double a;
        double imc;
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("CALCULO IMC");
        
        System.out.println("Digite o seu peso: ");
        m = scanner.nextInt();
        
        System.out.println("Digite a sua altura: ");
        a = scanner.nextDouble();
        
        a = Math.pow(a, a);
        imc = m/a;
        
        if(imc > 30){
            System.out.println("Você está acima obeso, procure um médico!");
        }
        
        if(imc <= 30){
            System.out.println("Você está com o peso ideal");
        }
        
        
    
    }
}
