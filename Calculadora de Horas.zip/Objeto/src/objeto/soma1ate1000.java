/*
 Imprima a soma de 1 até 1000
 */
package objeto;


public class soma1ate1000 {
    public static void main(String[] args) {
        
        int n=0;
        
        for(int i = 1; i <= 1000; i++){
                
            n=n+i;
            
        }
    
        System.out.println(n);
    }
    
}
