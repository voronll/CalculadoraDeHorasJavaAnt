/* IMPRIMA TODOS OS NÚMEROS DE 150 A 300. */

package objeto;

public class Objeto {

    public static void main(String[] args) {
        for(int i = 150; i < 300; i++){

            System.out.println(i);
            
                   
        }
        
    }
    
}
