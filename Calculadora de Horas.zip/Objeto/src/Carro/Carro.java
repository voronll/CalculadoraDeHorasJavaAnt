package Carro;

import javax.swing.JOptionPane;

/**
 * ANOTAÇÕES:
 *  JOptionPane: mostra um pop-up na tela
 *  
 * 
 * _____________________________________________________________________________
 * @voronll
 */
public class Carro {
    //Atributos (membros de um objeto)
    public String marca;
    public int ano;
    public int marcha;
    public boolean ligado;
    public boolean freio =true;
    public int velocidade;
    
    public void ligar(){
        if(this.ligado == false){
            this.ligado = true;
            // System.out.println("Carro ligado!");
            JOptionPane.showMessageDialog(null, "Carro ligado!");
        }
        else{
            System.out.println("O carro já está ligado!");
        }
    }
    
    public void acelerar(int velocidade){
        if(this.ligado == true){
            if(this.freio == false){
                if(this.marcha == 0){
                    JOptionPane.showMessageDialog(null, "Carro está em ponto morto!");
                }
                else if(this.marcha == 1){
                    if(velocidade < 30){
                        this.velocidade = velocidade; //atribui o valor passado pelo parametro velocidade para o atributo velocidadade
                        System.out.println("Acelerando a: " + velocidade +"km/h");
                    }
                }
            }
        }
        
    }
    
    public void desligar(){
        if(this.ligado == true){
            this.ligado = false;
            System.out.println("Carro desligado!");
        }
        else{
            System.out.println("Carro não está ligado!");
        }
   
    }
    
    public void trocarMarcha(){
        System.out.println("Marcha trocada!");
        
        
    }
    
    public void freio(){
        
        
    }
    
    
    
}
