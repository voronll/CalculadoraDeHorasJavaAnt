/*
 * FATORIAL
 */
package objeto;

public class fatorial {
    public static void main(String[] args) {
        int f = 1;
        
        for(int n = 1; n<= 10; n++){
            f = f * n;
        }
        
        System.out.println(f);
        
        
        
    }
}
