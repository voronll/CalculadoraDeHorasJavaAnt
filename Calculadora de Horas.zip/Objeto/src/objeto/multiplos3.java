/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objeto;

/**
 *
 * @author eduardo.4989
 */
public class multiplos3 {
    public static void main(String[] args) {
        int i;
        for( i = 1; i < 100; i++){
        if(i%3 == 0){
        System.out.println(i);
        }

    }
        
    }
}
