package Carro;

/**
 * ANOTAÇÕES:
 * 
 * 
 * 
 * _____________________________________________________________________________
 * @voronll
 */
public class Main {
    public static void main(String[] args) {
        
        Carro Golf = new Carro();
        Golf.ligar();
        Golf.freio = false;
        Golf.trocarMarcha();
        // Golf.marcha = 1; não vai funcionar, tem método trocarMarcha
        Golf.acelerar(50);
        Golf.trocarMarcha();
        Golf.desligar();
        
        System.out.println("_______________________________________________");
        
        Carro Civic = new Carro();
        Civic.ligar();
        Civic.freio = false;
        Civic.trocarMarcha();
        Civic.ligar();
        Civic.acelerar(80);
        Civic.desligar();
        
 
        
        
    }
}
